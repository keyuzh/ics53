// Keyu Zhang
// keyuz4


// Header file for hw0.c

#include<stdio.h>
#include<stdlib.h>

void printArg(char*, int);
