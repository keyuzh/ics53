// Useage statement
#define USAGE "usage: 53secret -L | -W MESSAGE [-S NUM] [-O] [-P]"

#include <stdio.h>
#include <stdlib.h>
#include "helpers1.h"
